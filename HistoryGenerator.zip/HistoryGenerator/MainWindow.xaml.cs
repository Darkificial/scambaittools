﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HistoryGenerator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string Csv(string csvFileContent)
        {
            var columnsOrg = csvFileContent.Split('\n')[0].Split(';').ToList();

            return columns.ToStrin();
        }
        public static string order(string strng)
        {
            if (string.IsNullOrEmpty(input))
                return true;

            Stack<char> brackets = new Stack<char>();

            foreach (var c in input)
            {
                if (c == '[' || c == '{' || c == '(')
                    brackets.Push(c);
                else if (c == ']' || c == '}' || c == ')')
                {
                    // Too many closing brackets, e.g. (123))
                    if (brackets.Count <= 0)
                        return false;

                    char open = brackets.Pop();

                    // Inconsistent brackets, e.g. (123]
                    if (c == '}' && open != '{' ||
                        c == ')' && open != '(' ||
                        c == ']' && open != '[')
                        return false;
                }
            }

            // Too many opening brackets, e.g. ((123) 
            if (brackets.Count > 0)
                return false;

            return true;
            var r = new Regex(@"
    func([a-zA-Z_][a-zA-Z0-9_]*) # The func name

    \(                      # First '('
        (?:                 
        [^()]               # Match all non-braces
        |
        (?<open> \( )       # Match '(', and capture into 'open'
        |
        (?<-open> \) )      # Match ')', and delete the 'open' capture
        )+
        (?(open)(?!))       # Fails if 'open' stack isn't empty!

    \)                      # Last ')'
", RegexOptions.IgnorePatternWhitespace);
            var nums = strng.Split(' ');
            return  string.Join(" ",nums.Select(x => new { org = x, Weight = x.Select(c => Convert.ToInt32(c)).Sum() }).OrderBy(x => x.Weight).Select(x=>x.org));

    }
        public MainWindow()
        {
            InitializeComponent();
            //var url = "https://mabanque.bnpparibas/";
            //var trim = url.Substring(0, url.LastIndexOf('/') - 1);
        }
        List<Tuple<string, string>> urlTitles = new List<Tuple<string, string>>();
        private void GenerateHistory(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(filePath.Text))
            {
                MessageBox.Show("Please select csv file... ");
                return;
            }
            string csvFile = filePath.Text;
            if (!File.Exists(csvFile))
            {
                MessageBox.Show("File not present... " + csvFile);
                return;
            }
            bool isGenerateFavicon = chkGenFavicon.IsChecked.Value;
            bool isGenerateHistory = chkDelete.IsChecked.Value;
            Task.Run(() =>
            {

                try
                {
                    var csvData1 = File.ReadAllLines(csvFile);

                    UpdateStatus("Generating cache...");
                    if (isGenerateFavicon)
                    {
                        var distinctUrls = csvData1.Select(x => x.Split(',')[0]).Distinct().ToList();
                        try
                        {
                            // distinctUrls = distinctUrls.Select(x => x.Substring(0, x.LastIndexOf('/') - 1)).Distinct().ToList();
                        }
                        catch (Exception)
                        {
                            distinctUrls = csvData1.Select(x => x.Split(',')[0]).Distinct().ToList();
                        }
                        for (int i = 0; i < distinctUrls.Count(); i++)
                        {
                            Process.Start("chrome.exe", distinctUrls[i]);
                            Thread.Sleep(new Random().Next(1000, 3000));
                            if (i != 0 && i % 5 == 0)
                            {
                                Thread.Sleep(2000);
                                UpdateStatus(" Waiting for closing chrome instances...");
                                try
                                {
                                    Process[] chrome = Process.GetProcessesByName("chrome");

                                    foreach (var chromeProcess in chrome)
                                    {
                                        if (chromeProcess.MainWindowHandle == IntPtr.Zero) // some have no UI
                                            continue;

                                        AutomationElement element = AutomationElement.FromHandle(chromeProcess.MainWindowHandle);
                                        if (element != null)
                                        {
                                            ((WindowPattern)element.GetCurrentPattern(WindowPattern.Pattern)).Close();
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {

                                    UpdateStatus("Error while closing chrome instances...");
                                }
                            }
                        }

                    }

                    Thread.Sleep(2000);
                    UpdateStatus(" Waiting for closing chrome instances...");
                    try
                    {
                        Process[] chrome = Process.GetProcessesByName("chrome");

                        foreach (var chromeProcess in chrome)
                        {
                            if (chromeProcess.MainWindowHandle == IntPtr.Zero) // some have no UI
                                continue;

                            AutomationElement element = AutomationElement.FromHandle(chromeProcess.MainWindowHandle);
                            if (element != null)
                            {
                                ((WindowPattern)element.GetCurrentPattern(WindowPattern.Pattern)).Close();

                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        UpdateStatus("Error while closing chrome instances...");
                    }

                    //if (MessageBox.Show("Close all chrome instance and press ok") == MessageBoxResult.OK)
                    //{

                    //}

                    string pathToHistory = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Google\Chrome\User Data\Default\History";
                    SQLiteConnection connection = new System.Data.SQLite.SQLiteConnection(@"Data Source=" + pathToHistory + ";Version=3;new=false;datetimeformat=CurrentCulture");


                    try
                    {
                        connection.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Close all chrome instance and try again");
                        return;
                    }

                    if (isGenerateHistory)
                    {
                        UpdateStatus("Deleting old history...");

                        string qrystr1 = "delete from urls; \n delete from visits; ";
                        var cmd11 = new SQLiteCommand(qrystr1, connection);
                        cmd11.ExecuteNonQuery();
                    }
                    UpdateStatus("Generating titles...");

                    var csvData = File.ReadAllLines(csvFile);
                    foreach (var item in csvData)
                    {
                        var url = item.Split(',')[0];
                        int dayDifference = 0;
                        try
                        {
                            dayDifference = Convert.ToInt32(item.Split(',')[1]);
                        }
                        catch (Exception)
                        {
                        }
                        var timeStamp = (((DateTimeOffset)DateTime.Now.AddDays(-1 * dayDifference).AddMinutes(new Random().Next(-500, 500))).ToUnixTimeSeconds() + 11644473600) * 1000000;
                        var title = url;
                        try
                        {

                            if (urlTitles.Where(i => i.Item1 == url).Count() == 0)
                            {
                                WebClient x = new WebClient();
                                x.Encoding = Encoding.UTF8;
                                string source = x.DownloadString(url);
                                title = Regex.Match(source, @"\<title\b[^>]*\>\s*(?<Title>[\s\S]*?)\</title\>",
            RegexOptions.IgnoreCase).Groups["Title"].Value;
                                urlTitles.Add(new Tuple<string, string>(url, title));
                            }
                            else
                            {
                                title = urlTitles.Where(i => i.Item1 == url).FirstOrDefault().Item2;
                            }
                        }
                        catch (Exception Ex)
                        {
                            title = string.Empty;
                        }
                        try
                        {

                        }
                        catch (Exception ex)
                        {

                            throw;
                        }
                        try
                        {
                            string qrystr = "insert into urls(url, title,last_visit_time,visit_count,typed_count ) values('" + url + "','" + title.ToString().Replace("'", "''") + "','" + timeStamp + "',1,1)";
                            var cmd1 = new SQLiteCommand(qrystr, connection);
                            cmd1.ExecuteNonQuery();
                            qrystr = "SELECT last_insert_rowid()";
                            cmd1 = new SQLiteCommand(qrystr, connection);
                            var id = cmd1.ExecuteScalar();
                            qrystr = "insert into visits(url, visit_time,visit_duration,from_visit,transition,segment_id) values(" + id + "," + timeStamp + ", 42047037,0,805306376,0)";
                            cmd1 = new SQLiteCommand(qrystr, connection);
                            cmd1.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    UpdateStatus("Completed Successfully...");
                }
                catch (Exception ex)
                {
                    UpdateStatus("Failed...");
                }
            });
        }

        private object GetTitle(string url)
        {
            throw new NotImplementedException();
        }

        private void UpdateStatus(string content)
        {
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                status.Text = content;
            }));
        }

        private void BrowseFile(object sender, RoutedEventArgs e)
        {
            string csvFile = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.DefaultExt = ".csv";
            dialog.Filter = "comma seperated values (.csv)|*.csv";
            var res = dialog.ShowDialog();
            if (res.HasValue)
            {
                if (res.Value)
                {
                    filePath.Text = dialog.FileName;
                    csvFile = dialog.FileName;
                }
            }
        }
    }
}
